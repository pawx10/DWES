<hr/>
<nav>
    Menú de navegación: 
    <a href='index.php'>Home</a>
    
    <a href='login.php'>Iniciar Sesión</a>
    <a href='registro.php'>Registro</a>
    <a href='logout.php'>Cerrar Sesión</a>
</nav>
<hr/>